#ifndef __TIME_H
#define __TIME_H

#include "public.h"

void time0_init(void);

#endif
