#include "reg52.h"

void main()
{
	while(1)
	{
		
	}
}