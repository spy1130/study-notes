#ifndef _bluetooth_H
#define _bluetooth_H

#include "public.h"

void bluetooth_control_init(void);
void bluetooth_control(void);

#endif